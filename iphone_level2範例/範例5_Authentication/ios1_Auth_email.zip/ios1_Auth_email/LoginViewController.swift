//
//  LoginViewController.swift
//  ios1
//
//  Created by mac on 2017/11/20.
//  Copyright © 2017年 mac. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {

    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func userLogin(_ sender: UIButton) {
        Auth.auth().signIn(withEmail: emailField.text!, password: passwordField.text!) { (user:User?, error:Error?) in
            if let _ = user,error == nil{
                self.dismiss(animated: true, completion: nil);
            }else{
                let alertController = UIAlertController(title: "login失敗", message: error?.localizedDescription, preferredStyle: .alert);
                let alertAction = UIAlertAction(title: "OK", style: .default, handler: nil);
                alertController.addAction(alertAction);
                self.present(alertController, animated: true, completion: nil);
            }
        }
    }
    
    
}
