//
//  ViewController.swift
//  ios1
//
//  Created by mac on 2017/11/20.
//  Copyright © 2017年 mac. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated);
        if Auth.auth().currentUser == nil {
            print("沒有登入");
            performSegue(withIdentifier: "goLogin", sender: nil);
        }else{
            self.title = Auth.auth().currentUser?.email!;
        }
    }

    @IBAction func userLogout(_ sender: UIBarButtonItem) {
        let firebaseAuth = Auth.auth();
        if (try? firebaseAuth.signOut()) != nil {
             performSegue(withIdentifier: "goLogin", sender: nil);
        }
    }
    
}

