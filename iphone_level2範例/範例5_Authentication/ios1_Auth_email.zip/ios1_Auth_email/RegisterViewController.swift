//
//  RegisterViewController.swift
//  ios1
//
//  Created by mac on 2017/11/20.
//  Copyright © 2017年 mac. All rights reserved.
//

import UIKit
import Firebase

class RegisterViewController: UIViewController {
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func userOk(_ sender: UIButton) {
        guard  !emailField.text!.isEmpty || !passwordField.text!.isEmpty else{
            print("欄位有問題");
            return;
        }
        Auth.auth().createUser(withEmail: emailField.text!, password: passwordField.text!) { (user:User?, error:Error?) in
            if let _ = user, error == nil{
                print("加入成功");
                self.dismiss(animated: true, completion: nil);
            }else{
                print("加入失敗");
                print("\(error!)");
                let alertController = UIAlertController(title: "註冊失敗", message: error?.localizedDescription, preferredStyle: .alert);
                let alertAction = UIAlertAction(title: "OK", style: .default, handler: nil);
                alertController.addAction(alertAction);
                self.present(alertController, animated: true, completion: nil);
            }
        }
    }
    

}
