//
//  DHTViewController.swift
//  ios1
//
//  Created by 徐國堂 on 2017/10/31.
//  Copyright © 2017年 Gjun. All rights reserved.
//

import UIKit
import Firebase

class DHTViewController: UIViewController {
    lazy var DHTref:DatabaseReference! = Database.database().reference(withPath: "DHT");
    
    @IBOutlet weak var HumidityField: UITextField!
    @IBOutlet weak var FahrenheitField: UITextField!
    @IBOutlet weak var FahrenheitIndexField: UITextField!
    @IBOutlet weak var CelsiusField: UITextField!
    @IBOutlet weak var CelsiusIndexField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        DHTref.observe(.value, with: {
            (datasnapshot:DataSnapshot) -> Void in
            if let dhtDict = datasnapshot.value as? [String:String]{                
                self.HumidityField.text = "濕度:\(dhtDict["Humidity"] ?? "不明")";
                self.FahrenheitField.text = "華氏:\(dhtDict["Fahrenheit"] ?? "不明")";
                self.FahrenheitIndexField.text = "華氏指數:\(dhtDict["FahrenheitIndex"] ?? "不明")"
                self.CelsiusField.text = "攝氏:\(dhtDict["Celsius"] ?? "不明")";
                self.CelsiusIndexField.text = "攝氏指數:\(dhtDict["CelsiusIndex"] ?? "不明")";
            }
        });
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    

}
