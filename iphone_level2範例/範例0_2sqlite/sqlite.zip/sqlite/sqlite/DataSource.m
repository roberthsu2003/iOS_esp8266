//
//  DataSource.m
//  sqlite
//
//  Created by n135 on 2018/1/28.
//  Copyright © 2018年 n135. All rights reserved.
//

#import "DataSource.h"
#import "sqlite3.h"
#import "City.h"

@interface DataSource();
-(NSString*)targetPath;
@end

@implementation DataSource
+(instancetype)shareInstance{
    static DataSource *dataSource = nil;
    if (!dataSource) {
       dataSource = [[DataSource alloc] init];
    }
    return dataSource;
}

-(NSString*)targetPath{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths lastObject];
    NSString *targetPath = [path stringByAppendingString:@"/citys.db"];
    return targetPath;
}


-(NSArray*)getCityNamesWith:(NSString*)continent{
    
    NSString* targetPath = [self targetPath];
    sqlite3 *conn;
    if (sqlite3_open([targetPath UTF8String], &conn) != SQLITE_OK){
        sqlite3_close(conn);
        return nil;
    }
    
    NSLog(@"連線成功");
    sqlite3_stmt *stmt;
    NSString *sqlString = @"select * from city where continent= ?";
    int result = sqlite3_prepare_v2(conn, [sqlString UTF8String], -1, &stmt, nil);
    if (result != SQLITE_OK){
        sqlite3_finalize(stmt);
        sqlite3_close(conn);
         return nil;
    }
    sqlite3_bind_text(stmt, 1, [continent UTF8String], -1, NULL);
    NSMutableArray *citys = [[NSMutableArray alloc] init];
    while(sqlite3_step(stmt) == SQLITE_ROW){
        int numId = sqlite3_column_int(stmt, 0);
        
        
        const unsigned char *cityName_C = sqlite3_column_text(stmt, 1);
        NSString *cityName = [[NSString alloc] initWithUTF8String:(const char*)cityName_C];
       
        
        const unsigned char *continent_C = sqlite3_column_text(stmt, 2);
        NSString *continent = [[NSString alloc] initWithUTF8String:(const char*)continent_C];
        
        
        const unsigned char *country_C = sqlite3_column_text(stmt, 3);
        NSString *country = [[NSString alloc] initWithUTF8String:(const char*)country_C];
        
        
        const unsigned char *image_C = sqlite3_column_text(stmt, 4);
        NSString *image = [[NSString alloc] initWithUTF8String:(const char*)image_C];
        
        
        City *city = [[City alloc] initWithNumId:numId cityName:cityName continent:continent country:country image:image];
        
        [citys addObject:city];
        
        
    }
    
    sqlite3_finalize(stmt);
    sqlite3_close(conn);
    
    return citys;
    
}
@end
