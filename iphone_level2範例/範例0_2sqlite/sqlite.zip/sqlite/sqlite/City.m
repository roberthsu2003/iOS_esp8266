//
//  City.m
//  sqlite
//
//  Created by n135 on 2018/2/4.
//  Copyright © 2018年 n135. All rights reserved.
//

#import "City.h"

@implementation City
-(instancetype)initWithNumId:(int)numId cityName:(NSString*)cityName continent:(NSString*)continent country:(NSString*)country image:(NSString*)imageName{
    self = [super init];
    if (self) {
        self.numId = numId;
        self.cityName = cityName;
        self.continent = continent;
        self.country = country;
        self.imageName = imageName;
    }
    return self;
}
@end
