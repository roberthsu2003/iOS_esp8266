//
//  ViewController.swift
//  sqlite
//
//  Created by n135 on 2018/1/28.
//  Copyright © 2018年 n135. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {
    var citys:[City] = [];
    @IBOutlet var seg:UISegmentedControl!;
    var continents:[String] = ["Asia","Europe","North America","South America","Oceania"];
    override func viewDidLoad() {
        super.viewDidLoad()
        let continent = continents[seg.selectedSegmentIndex];
        print(continent);
        let dataSource = DataSource.shareInstance();
        if let citys = dataSource?.getCityNames(with: continent) as? [City]{
            self.citys = citys;
        }
        for city in self.citys{
            print(city.cityName);
        }
        
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func segChange(_ sender:UISegmentedControl){
        let continent = continents[sender.selectedSegmentIndex]
        let dataSource = DataSource.shareInstance();
        if let citys = dataSource?.getCityNames(with: continent) as? [City]{
            self.citys = citys;
            tableView.reloadData();
        }
    }
}


extension ViewController{
   override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
    return citys.count;
    }
    
   override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
    let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath);
    let city = citys[indexPath.row];
    cell.textLabel?.text = city.cityName;
    return cell;
    }
}

