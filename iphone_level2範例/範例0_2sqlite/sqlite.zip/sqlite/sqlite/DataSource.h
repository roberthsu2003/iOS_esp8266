//
//  DataSource.h
//  sqlite
//
//  Created by n135 on 2018/1/28.
//  Copyright © 2018年 n135. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataSource : NSObject

+(instancetype)shareInstance;
-(NSArray*)getCityNamesWith:(NSString*)continent;
@end
