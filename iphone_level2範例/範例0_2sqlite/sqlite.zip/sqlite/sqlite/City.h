//
//  City.h
//  sqlite
//
//  Created by n135 on 2018/2/4.
//  Copyright © 2018年 n135. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface City : NSObject
@property(nonatomic, assign) int numId;
@property(nonatomic) NSString *cityName;
@property(nonatomic) NSString *continent;
@property(nonatomic) NSString *country;
@property(nonatomic) NSString *imageName;
-(instancetype)initWithNumId:(int)numId cityName:(NSString*)cityName continent:(NSString*)continent country:(NSString*)country image:(NSString*)imageName;
@end
