//
//  SubViewController.swift
//  jsonDecoder
//
//  Created by 徐國堂 on 2017/11/8.
//  Copyright © 2017年 Gjun. All rights reserved.
//

import UIKit
import MapKit

struct AllStation:Codable{
    struct Station:Codable{
        let region:String;
        let name:String;
        let tel:String;
        let add:String;
        let lat:Double;
        let long:Double;
    }
    let allStations:[Station];
}

class SubViewController: UICollectionViewController {
    var  urlSession:URLSession!;
    var allStation:AllStation!;
     let allStationsPath = \SubViewController.allStation.allStations;
    override func viewDidLoad() {
        super.viewDidLoad()
        let collectionViewFlowLayout = self.collectionViewLayout as! UICollectionViewFlowLayout;
        collectionViewFlowLayout.itemSize = self.view.bounds.size;
        
       
        guard let url = URL(string: "https://iostest-64ed7.firebaseapp.com/") else {
            return;
        }
       
        urlSession = URLSession.shared;
        let downloadTask = urlSession.downloadTask(with: url) { (url:URL?, response:URLResponse?, error:Error?) in
            guard let url = url, let response = response else {
                return;
            }
            
            guard error == nil else {
                return;
            }
            guard (response as! HTTPURLResponse).statusCode == 200  else {
                return;
            }
            
            guard let data = try? Data.init(contentsOf: url) else {
                return;
            }
            
            print(String.init(data: data, encoding: String.Encoding.utf8)!);
            
            let jsonDecoder = JSONDecoder();
            self.allStation = try? jsonDecoder.decode(AllStation.self, from: data);
            
            for station in self[keyPath:self.allStationsPath]{
                print(station.add);
            }
            
            DispatchQueue.main.sync {
                self.collectionView?.reloadData();
            }
            
           
        }
        downloadTask.resume();
        
        
       
        
    }

    
    // MARK: UICollectionViewDataSource

  

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        if allStation == nil {
            return 0;
        }else{
            return self[keyPath:allStationsPath].count;
        }
        
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CELL", for: indexPath) as! SubCollectionViewCell;
        let station = self[keyPath:allStationsPath][indexPath.row];
        cell.addLabel?.text = "地址:\(station.add)";
        cell.nameLabel?.text = "分校名:\(station.name)";
        cell.regionLabel?.text = "地區:\(station.region)";
        cell.telLabel?.text = "電話:\(station.tel)";
        let mapView:MKMapView = cell.mapView;
        let annotation = MKPointAnnotation();
        let coordinate = CLLocationCoordinate2D(latitude: station.lat, longitude: station.long);
        annotation.coordinate = coordinate;
        mapView.addAnnotation(annotation);
        let region = MKCoordinateRegionMakeWithDistance(coordinate, 250, 250);
        mapView.setRegion(region, animated: false);
        
        return cell;        
    }

    

}
